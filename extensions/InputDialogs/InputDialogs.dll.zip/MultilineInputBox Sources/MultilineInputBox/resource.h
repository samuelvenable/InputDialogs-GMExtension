#define IDD_SINGLELINE  100
#define IDD_MULTILINE   101
#define IDC_PROMPT      102
#define IDC_EDIT        103
#define IDC_CANCEL      104
#define IDC_STATIC      105
